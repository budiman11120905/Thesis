<html>
<head>
</head>
<body>
<?

$host="localhost";
$user="root";
$pass="password";
$db="hid_db";
$entries=3;


$koneksi=mysql_connect($host,$user,$pass);
$database=mysql_select_db($db,$koneksi);
$tanggal=date('D, d-M-Y H:i:s');
/*
if ($koneksi)
{
	echo "berhasil : )";
}else{
	echo "Gagal !";
}
*/
?>

</body>
</html>
