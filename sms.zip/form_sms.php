<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Form SMS - BT Developer</title>
</head>

<body>
<form method="post" action="sends.php">
No. HP Tujuan : <input type="text" name="nohp" value="+62"><br>
Pesan : <textarea name="msg"></textarea><br>
<input type="submit" name="submit" value="Kirim SMS">
</form>
</body>
</html>
