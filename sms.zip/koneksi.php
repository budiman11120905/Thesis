<?php
mysql_connect("localhost","root","password") or die ("Gagal Mengkoneksikan Ke Database");
mysql_select_db("login1") or die ("Database Tidak Ditemukan");
?>