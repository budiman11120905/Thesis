<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<style type="text/css">
.field1{background-color:#0066CC; color:#FFFFFF; font-family:Arial, Helvetica, sans-serif; font-size:18px}
.field2{ color:#000000; font-family:Arial, Helvetica, sans-serif; font-size:18px; font-style:oblique}
p{ color:#0000FF; font-family:Arial, Helvetica, sans-serif; font-size:24px; font-variant:normal}
</style>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Form Output Keluar Masuk Barang</title>
</head>

<body>
<p><img src="images/r3.JPG" width="50" height="50" /></p>
<p>Form Output Keluar - Masuk Barang<br />Pada PT. Ralia Mandiri</p>
<table width="100%" border="1" cellspacing="0" cellpadding="0">
  <tr>
    <td><div class="field1" align="center">Hari/Tanggal</div></td>
    <td><div class="field1" align="center">No.SPJ</div></td>
    <td><div  class="field1" align="center">Pick-up</div></td>
    <td><div class="field1" align="center">Tujuan/Destination</div></td>
    <td colspan="2"><div align="center" class="field1">
      <i>Quantity</i><br />
      <i>(Coly dan Kg) </i>
    </div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><div align="center"></div></td>
    <td><div align="center"></div></td>
  </tr>
  
</table>
<br />
<hr />
<br />
<table width="100%" border="1" cellspacing="0" cellpadding="0">
  <tr>
    <td><div class="field1" align="center">Jenis Barang </div></td>
    <td><div class="field1" align="center">Merk</div></td>
    <td><div class="field1" align="center">Dikirim Pada Tanggal </div></td>
    <td><div class="field1" align="center">Melalui Agen </div></td>
    <td><div class="field1" align="center">No Surat Agen </div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
<br />
<hr />
<br />
<table width="100%" border="1" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="4"><div class="field2" align="center">KETERANGAN PENGIRIMAN </div></td>
  </tr>
  <tr>
    <td><div class="field1" align="center">No.Surat Agen </div></td>
    <td><div class="field1" align="center">Via (Darat,Laut atau Udara)</div></td>
    <td><div class="field1" align="center">ETD/Tanggal Keberangkatan </div></td>
    <td><div class="field1" align="center">ETA/Tanggal Tiba </div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>

</body>
</html>
